#ifndef _PROXY_H_
#define _PROXY_H_

#include "common.h"
#include "utils.h"
#include "parser.h"

/*------------------------------Functions--------------------------------------*/

extern void* Proxy(void* arg);
extern void* Monitor(void* arg);

#endif
