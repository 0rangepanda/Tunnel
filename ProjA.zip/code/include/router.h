#ifndef _ROUTER_H_
#define _ROUTER_H_

#include "common.h"
#include "utils.h"
#include "parser.h"

/*------------------------------Functions--------------------------------------*/
extern void Cleanup(int sig_num);
extern void Router();

#endif
