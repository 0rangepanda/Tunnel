a) Reused Code:
  No
  
b) Complete:
  Stage 2 compelete

c) Portable:
  The same as stage 1
